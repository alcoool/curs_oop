<?php

interface Functii
{
    public function spala();
    public function naparleste();

}
