<?php

include 'Broasca.php';


$animal = new Broasca();

 $animal->setBlana(true);

$animal->sunet(1);

$animal->setOchi('mono');
echo $animal->getOchi();
