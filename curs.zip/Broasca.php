<?php
include 'Animal.php';

class Broasca extends Animal
{
    function sunet($obigat, $imperechere=false)
    {
        if($imperechere){
            echo 'miau miau';
        } else {
            echo 'Ham ham';
        }

        parent::sunet($imperechere);

        $ceva = $this->ochi;

        $this->faCaca();

    }
}